https://kubernetes.io/docs/concepts/workloads/controllers/replicaset/

- kubectl apply -f replicaset.yaml
- kubectl get pod -o wide
- kubectl describe pod <pod-name>
- kubectl get replicaset 
- kubectl describe replicaset nginx-replicaset
- kubectl delete pod <pod-name>
- kubectl get pod -o wide