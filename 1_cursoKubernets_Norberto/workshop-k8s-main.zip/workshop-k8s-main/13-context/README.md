
kubectl config get-contexts
kubectl config use-context <context-name> 
kubectl config delete-context <context-name>