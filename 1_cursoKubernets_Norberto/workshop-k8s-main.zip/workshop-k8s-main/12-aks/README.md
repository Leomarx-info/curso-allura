https://docs.microsoft.com/pt-br/azure/aks/concepts-clusters-workloads
https://docs.microsoft.com/pt-br/azure/aks/kubernetes-walkthrough
https://docs.microsoft.com/en-us/cli/azure/manage-azure-subscriptions-azure-cli
https://docs.microsoft.com/pt-br/azure/aks/concepts-clusters-workloads
https://docs.microsoft.com/pt-br/azure/architecture/reference-architectures/containers/aks-microservices/aks-microservices

# Comandos
az login
az account list --output table
az account set --subscription "<name>"
az aks get-credentials --resource-group <resource-group> --name <aks-name>
